# Seva Tech Warriors (PWA) - setup (free Firebase Spark plan)
1. console.firebase.google.com > Add project. Build > Authentication > Get started > enable Email/Password.
2. Build > Firestore Database > Create (production mode). Open the Rules tab, paste firestore.rules, Publish.
3. Project settings > Your apps > Web (</>) > copy the config into `cfg` near the top of index.html.
4. Deploy free: `npm i -g firebase-tools && firebase login && firebase init hosting` (public dir ".", don't overwrite files) then `firebase deploy`.
5. On Android, open the hosting URL in Chrome > menu > Install app / Add to Home screen.
6. Admin: tap Citizen > Create account with tetratechpvt.ltd.0@gmail.com, verify the email, then use "Admin login".
Responders: sign up, verify email, then the admin approves them in the Admin dashboard.
Not included (need Cloud Functions, which require billing, or the native Android app): approval emails with YES/NO links, background push notifications, siren/flashlight.
Edit the `CONTACT` line in index.html to add your real phone and WhatsApp numbers (digits with country code); the Contact section shows only the details you fill in.
Responders now choose Police, Fire fighter or Ambulance when signing up and only receive alerts for that service. Re-publish firestore.rules after updating, and delete any test responder accounts made before this update.
Live location sharing is in-app only: add trusted contacts by email. When they are logged in to the app (with the same email), your live location appears on their dashboard while your SOS is active. Re-publish firestore.rules after updating.


## Logo assets included
- `logo.png`: the supplied Seva Tech Warriors logo used by the splash and home screens.
- `icon-192.png` and `icon-512.png`: generated from the same supplied logo for browser and Android installation icons.
- The service worker cache is versioned `stw-v2` and includes all logo/icon files.
