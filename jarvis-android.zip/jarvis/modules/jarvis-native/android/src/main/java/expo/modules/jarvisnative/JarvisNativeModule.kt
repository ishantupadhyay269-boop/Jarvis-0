package expo.modules.jarvisnative

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import expo.modules.kotlin.Exceptions
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class JarvisNativeModule : Module() {
  private val ctx: Context get() = appContext.reactContext ?: throw Exceptions.ReactContextLost()
  private val prefs get() = ctx.getSharedPreferences("jarvis", Context.MODE_PRIVATE)
  private val admin get() = ComponentName(ctx, JarvisAdminReceiver::class.java)

  private fun launchSettings(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) }

  override fun definition() = ModuleDefinition {
    Name("JarvisNative")
    Events("onWake")

    OnCreate { WakeBus.listener = { p -> sendEvent("onWake", mapOf("phrase" to p)) } }
    OnDestroy { WakeBus.listener = null }

    // ---- wake word service ----
    Function("startWakeService") {
      ContextCompat.startForegroundService(ctx, Intent(ctx, WakeWordService::class.java)); true
    }
    Function("stopWakeService") { ctx.stopService(Intent(ctx, WakeWordService::class.java)); WakeBus.running = false; true }
    Function("isWakeServiceRunning") { WakeBus.running }
    Function("pauseWake") { WakeBus.paused.set(true); WakeBus.onPause?.invoke(); true }
    Function("resumeWake") { WakeBus.paused.set(false); true }
    Function("consumePendingWake") {
      val v = prefs.getBoolean("pending_wake", false)
      if (v) prefs.edit().putBoolean("pending_wake", false).apply()
      v
    }

    // ---- permissions / settings helpers ----
    Function("canDrawOverlays") { Settings.canDrawOverlays(ctx) }
    Function("requestOverlayPermission") {
      launchSettings(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))); true
    }
    Function("isIgnoringBatteryOptimizations") {
      (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    Function("requestIgnoreBatteryOptimizations") {
      launchSettings(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))); true
    }

    // ---- device admin / lock ----
    Function("isAdminActive") {
      (ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isAdminActive(admin)
    }
    Function("requestAdmin") {
      launchSettings(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
        putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Lets JARVIS lock your screen when you ask. It cannot unlock or read your PIN.")
      }); true
    }
    Function("lockNow") {
      val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
      if (!dpm.isAdminActive(admin)) false else { dpm.lockNow(); true }
    }

    // ---- device control ----
    Function("launchAppByName") { name: String ->
      val pm = ctx.packageManager
      val q = name.trim().lowercase()
      val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
      val matches = pm.queryIntentActivities(main, 0)
      val hit = matches.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
        ?: matches.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
      if (hit == null) null else {
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)
        if (i == null) null else { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); hit.loadLabel(pm).toString() }
      }
    }
    Function("setFlashlight") { on: Boolean ->
      val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
      val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
      if (id == null) false else { cm.setTorchMode(id, on); true }
    }
    Function("getVolume") {
      val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
      (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100) / am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    }
    Function("setVolume") { percent: Int ->
      val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
      val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
      am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent.coerceIn(0, 100) * max) / 100, AudioManager.FLAG_SHOW_UI); true
    }
  }
}
