package expo.modules.jarvisnative

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Foreground service that keeps a SpeechRecognizer loop running and watches for "Hello Jarvis".
 * Uses Android's built-in recognizer (free, offline-capable on many devices). It is NOT a
 * dedicated low-power hotword DSP: expect battery cost and OEM-specific behaviour.
 */
class WakeWordService : Service() {
  private val handler = Handler(Looper.getMainLooper())
  private var recognizer: SpeechRecognizer? = null
  private var tts: TextToSpeech? = null
  private var ttsReady = false
  private var lastWake = 0L

  companion object {
    const val CH_SERVICE = "jarvis_service"
    const val CH_WAKE = "jarvis_wake"
    val WAKE_WORDS = listOf("jarvis", "jarvish", "jarwis", "जार्विस", "जारविस", "जर्विस", "जार्विश")
  }

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel(CH_SERVICE, "JARVIS listening", NotificationManager.IMPORTANCE_LOW))
    nm.createNotificationChannel(NotificationChannel(CH_WAKE, "JARVIS wake", NotificationManager.IMPORTANCE_HIGH))
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val launch = packageManager.getLaunchIntentForPackage(packageName)
    val pi = PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val n = Notification.Builder(this, CH_SERVICE)
      .setContentTitle("JARVIS is listening for \"Hello Jarvis\"")
      .setContentText("Microphone active. Tap to open.")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setOngoing(true)
      .setContentIntent(pi)
      .build()
    if (Build.VERSION.SDK_INT >= 29) startForeground(1001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    else startForeground(1001, n)

    if (!WakeBus.running) {
      WakeBus.running = true
      tts = TextToSpeech(this) { s ->
        ttsReady = s == TextToSpeech.SUCCESS
        if (ttsReady) tts?.language = Locale("en", "IN")
      }
      WakeBus.onPause = { handler.post { recognizer?.cancel() } }
      handler.post { listen() }
    }
    return START_STICKY
  }

  private fun listen() {
    if (!WakeBus.running) return
    if (WakeBus.paused.get()) { handler.postDelayed({ listen() }, 800); return }
    if (!SpeechRecognizer.isRecognitionAvailable(this)) { stopSelf(); return }
    recognizer?.destroy()
    recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
      r.setRecognitionListener(object : RecognitionListener {
        override fun onResults(b: Bundle?) { if (!check(b)) restart(250) }
        override fun onPartialResults(b: Bundle?) { check(b) }
        override fun onError(e: Int) {
          restart(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || e == SpeechRecognizer.ERROR_CLIENT) 1500 else 300)
        }
        override fun onReadyForSpeech(p: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(v: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(t: Int, p: Bundle?) {}
      })
      val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
      }
      r.startListening(i)
    }
  }

  private fun restart(delay: Long) {
    if (!WakeBus.running) return
    handler.postDelayed({ listen() }, delay)
  }

  /** Returns true if the wake phrase was found and handled. */
  private fun check(b: Bundle?): Boolean {
    val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return false
    val hit = list.any { s -> val l = s.lowercase(Locale.ROOT); WAKE_WORDS.any { l.contains(it) } }
    if (!hit) return false
    val now = SystemClock.elapsedRealtime()
    if (now - lastWake < 4000) return true
    lastWake = now
    recognizer?.cancel()
    onWake()
    restart(8000) // give TTS + app launch room; JS pauses the service while it listens
    return true
  }

  private fun onWake() {
    getSharedPreferences("jarvis", Context.MODE_PRIVATE).edit().putBoolean("pending_wake", true).apply()
    val go = {
      handler.post {
        bringAppToFront()
        WakeBus.listener?.invoke("hello jarvis")
      }
      Unit
    }
    if (ttsReady) {
      tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
        override fun onStart(id: String?) {}
        override fun onDone(id: String?) { go() }
        @Deprecated("Deprecated in Java") override fun onError(id: String?) { go() }
      })
      tts?.speak("Yes Sir.", TextToSpeech.QUEUE_FLUSH, null, "wake")
    } else go()
  }

  private fun bringAppToFront() {
    val launch = packageManager.getLaunchIntentForPackage(packageName)?.apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP)
    } ?: return
    // Android 10+ blocks background activity starts unless the app holds "draw over other apps".
    if (Build.VERSION.SDK_INT < 29 || Settings.canDrawOverlays(this)) {
      try { startActivity(launch) } catch (_: Exception) {}
    }
    // Fallback: heads-up / full-screen notification the user can tap.
    val pi = PendingIntent.getActivity(this, 1, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    val n = Notification.Builder(this, CH_WAKE)
      .setContentTitle("JARVIS")
      .setContentText("Yes Sir. Tap to continue.")
      .setSmallIcon(android.R.drawable.ic_btn_speak_now)
      .setAutoCancel(true)
      .setContentIntent(pi)
      .setFullScreenIntent(pi, true)
      .build()
    getSystemService(NotificationManager::class.java).notify(1002, n)
  }

  override fun onDestroy() {
    WakeBus.running = false
    WakeBus.onPause = null
    handler.removeCallbacksAndMessages(null)
    recognizer?.destroy(); recognizer = null
    tts?.shutdown(); tts = null
    super.onDestroy()
  }
}
