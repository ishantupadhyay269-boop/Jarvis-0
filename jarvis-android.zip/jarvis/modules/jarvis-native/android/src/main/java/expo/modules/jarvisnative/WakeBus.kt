package expo.modules.jarvisnative

import java.util.concurrent.atomic.AtomicBoolean

/** Tiny in-process bridge between the foreground service and the JS module. */
object WakeBus {
  @Volatile var running = false
  /** JS sets this while it uses the microphone itself (only one recognizer can hold the mic). */
  val paused = AtomicBoolean(false)
  @Volatile var onPause: (() -> Unit)? = null
  @Volatile var listener: ((String) -> Unit)? = null
}
