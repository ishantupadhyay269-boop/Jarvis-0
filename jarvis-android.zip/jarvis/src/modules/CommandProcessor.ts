import { AndroidDeviceController as D } from './AndroidDeviceController';
import { AuthenticationManager } from './AuthenticationManager';

export interface CommandDeps { speak: (t: string) => Promise<void> }
const T = 'Sir';

const OPEN = '(?:open|launch|start|kholo|khol do|खोलो|खोलिए|खोल दो|चालू करो|chalu karo)';
const num = (s: string) => (s.match(/\+?\d[\d\s-]{4,}/)?.[0] ?? '').replace(/[\s-]/g, '');

/**
 * Returns the spoken reply, or null when the text is not a device command
 * (the caller then sends it to the AI engine).
 */
export async function processCommand(raw: string, deps: CommandDeps): Promise<string | null> {
  const t = raw.toLowerCase().replace(/^(hello|hallo|hey|hi)\s+jarvis[,.]?\s*/, '').replace(/^jarvis[,.]?\s*/, '').trim();
  let m: RegExpMatchArray | null;

  // --- authentication (+ optional pending command) ---
  m = t.match(/^(?:authenticate me(?: and (.+))?|unlock (?:my )?phone|open my phone)$/);
  if (m) {
    await deps.speak(`Certainly, ${T}. Please authenticate to continue.`);
    if (!(await AuthenticationManager.available())) return `No fingerprint or screen lock is set up on this device, ${T}.`;
    if (!(await AuthenticationManager.authenticate())) return `Authentication failed, ${T}. I will not proceed.`;
    if (m[1]) return (await processCommand(m[1], deps)) ?? `Authenticated, ${T}, but I did not understand the follow-up command.`;
    return `Authenticated, ${T}. Android does not allow any app to unlock the lock screen, so please unlock the phone yourself.`;
  }

  // --- lock phone ---
  if (/^(lock (?:my |the )?(?:phone|screen)|phone lock karo|फोन लॉक करो)$/.test(t)) {
    if (!D.adminActive()) { D.requestAdmin(); return `I need device administrator permission to lock the screen, ${T}. Please approve it on the screen that just opened.`; }
    D.lockPhone(); return '';
  }

  // --- time / date ---
  if (/\b(what(?:'s| is) the time|time kya|समय क्या|टाइम क्या)\b/.test(t) || t === 'time') {
    return `It is ${new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}, ${T}.`;
  }
  if (/\b(date|today's date|aaj ki tarikh|आज की तारीख)\b/.test(t) && !/update/.test(t)) {
    return `Today is ${new Date().toLocaleDateString([], { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}, ${T}.`;
  }

  // --- battery / network ---
  if (/\b(battery|बैटरी)\b/.test(t)) {
    const b = await D.battery();
    return `Battery is at ${b.percent} percent${b.charging ? ' and charging' : ''}, ${T}.`;
  }
  if (/\b(network|internet|wifi status|connection)\b/.test(t) && /\b(status|check|am i|is)\b/.test(t)) {
    const n = await D.network();
    return n.online ? `You are online via ${n.type}, ${T}.` : `You appear to be offline, ${T}.`;
  }

  // --- flashlight ---
  m = t.match(/\b(?:(?:turn |switch )?(on|off)(?: the)? (?:flashlight|torch)|(?:flashlight|torch) (on|off)|torch (jalao|band karo))\b/);
  if (m) {
    const on = (m[1] || m[2] || (m[3] === 'jalao' ? 'on' : 'off')) === 'on';
    return D.flashlight(on) ? `Flashlight ${on ? 'on' : 'off'}, ${T}.` : `I could not control the flashlight on this device, ${T}.`;
  }

  // --- volume ---
  m = t.match(/\bvolume (?:to |set to )?(\d{1,3})(?:\s*(?:percent|%))?/);
  if (m) { D.volume.set(parseInt(m[1], 10)); return `Volume set to ${Math.min(100, parseInt(m[1], 10))} percent, ${T}.`; }
  if (/\b(volume (up|increase)|louder|awaaz badhao|आवाज़ बढ़ाओ)\b/.test(t)) { D.volume.set(D.volume.get() + 15); return `Volume increased, ${T}.`; }
  if (/\b(volume (down|decrease)|quieter|awaaz kam karo|आवाज़ कम करो)\b/.test(t)) { D.volume.set(D.volume.get() - 15); return `Volume decreased, ${T}.`; }

  // --- alarm ---
  m = t.match(/\b(?:set (?:an )?alarm (?:for|at)|alarm (?:set karo|lagao))\s*(\d{1,2})(?::(\d{2}))?\s*(am|pm)?/);
  if (m) {
    let h = parseInt(m[1], 10); const min = parseInt(m[2] ?? '0', 10);
    if (m[3] === 'pm' && h < 12) h += 12; if (m[3] === 'am' && h === 12) h = 0;
    await D.setAlarm(h, min); return `Opening the alarm for ${h}:${String(min).padStart(2, '0')}, ${T}. Please confirm it in the clock app.`;
  }

  // --- YouTube ---
  m = t.match(/\b(?:play|search)\s+(.+?)\s+on youtube\b/) ?? t.match(/\byoutube (?:par|pe)\s+(.+?)\s+(?:chalao|search karo)\b/);
  if (m) { await D.openYouTube(m[1]); return `Searching YouTube for ${m[1]}, ${T}.`; }
  if (new RegExp(`^${OPEN}\\s+youtube$|^youtube\\s+${OPEN}$`).test(t)) { await D.openYouTube(); return `Opening YouTube, ${T}.`; }

  // --- camera / settings ---
  if (new RegExp(`^${OPEN}\\s+(?:the\\s+)?camera$|^camera\\s+${OPEN}$`).test(t)) { await D.openCamera(); return `Opening the camera, ${T}.`; }
  m = t.match(new RegExp(`^${OPEN}\\s+(?:the\\s+)?(?:(${D.settingsPages().join('|')})\\s+)?settings$|^(?:settings|सेटिंग्स)\\s+${OPEN}$`));
  if (m) { await D.openSettings(m[1] || 'main'); return `Opening settings, ${T}.`; }

  // --- phone / SMS ---
  m = t.match(/^(?:call|dial|phone)\s+(.+)$/);
  if (m) {
    const n = num(m[1]);
    if (!n) return `Android does not let me search your contacts without extra permission, ${T}. Please give me a number.`;
    await D.dial(n); return `Opening the dialer with ${n}, ${T}. Press call to connect.`;
  }
  m = t.match(/^(?:send (?:an )?(?:sms|text|message)|text)\s+(?:to\s+)?(\+?[\d\s-]{5,})\s*(?:saying|that says|message|:)?\s*(.*)$/);
  if (m) { await D.sms(num(m[1]), m[2]); return `Composing your message, ${T}. Please press send.`; }

  // --- web search ---
  m = t.match(/^(?:search(?: the web| google)? for|google|search)\s+(.+)$/);
  if (m) { await D.search(m[1]); return `Searching for ${m[1]}, ${T}.`; }

  // --- generic open app (English + Hindi word order) ---
  m = t.match(new RegExp(`^${OPEN}\\s+(.+)$`)) ?? t.match(new RegExp(`^(.+?)\\s+${OPEN}$`));
  if (m) {
    const label = D.openApp(m[1].replace(/^the\s+|\s+app$/g, ''));
    return label ? `Opening ${label}, ${T}.` : `I could not find an app called ${m[1]}, ${T}.`;
  }

  return null;
}
