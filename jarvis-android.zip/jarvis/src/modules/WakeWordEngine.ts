import { PermissionsAndroid, Platform } from 'react-native';
import { Native, nativeAvailable } from '../native/JarvisNative';

export const WakeWordEngine = {
  available: nativeAvailable,
  async ensurePermissions(): Promise<boolean> {
    if (Platform.OS !== 'android') return false;
    const mic = await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.RECORD_AUDIO);
    if (Platform.Version >= 33) await PermissionsAndroid.request(PermissionsAndroid.PERMISSIONS.POST_NOTIFICATIONS);
    return mic === PermissionsAndroid.RESULTS.GRANTED;
  },
  async start(): Promise<boolean> {
    if (!nativeAvailable) return false;
    if (!(await WakeWordEngine.ensurePermissions())) return false;
    return Native.startWakeService();
  },
  stop: () => Native.stopWakeService(),
  isRunning: () => Native.isWakeServiceRunning(),
  /** Call while the app itself is using the mic. */
  pause: () => Native.pauseWake(),
  resume: () => Native.resumeWake(),
  consumePending: () => Native.consumePendingWake(),
  onWake: (cb: () => void) => Native.onWake(cb),
  health: () => ({
    overlay: Native.canDrawOverlays(),
    batteryExempt: Native.isIgnoringBatteryOptimizations(),
    running: Native.isWakeServiceRunning(),
  }),
};
