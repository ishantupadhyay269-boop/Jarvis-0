import React, { useEffect, useState } from 'react';
import { Alert, Modal, Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { Settings } from '../types';
import { Theme } from './theme';
import { WakeWordEngine } from '../modules/WakeWordEngine';
import { SpeechEngine } from '../modules/SpeechEngine';
import { AndroidDeviceController as D } from '../modules/AndroidDeviceController';
import { Native } from '../native/JarvisNative';

type Props = { visible: boolean; onClose: () => void; theme: Theme; settings: Settings; apply: (p: Partial<Settings>) => void; clear: () => void };

export default function SettingsScreen({ visible, onClose, theme: t, settings: s, apply, clear }: Props) {
  const [voices, setVoices] = useState<{ identifier: string; name: string }[]>([]);
  const [health, setHealth] = useState(WakeWordEngine.health());
  useEffect(() => { if (visible) { SpeechEngine.voices().then(setVoices as any); setHealth(WakeWordEngine.health()); } }, [visible]);

  const Row = ({ label, children }: any) => (
    <View style={st.row}><Text style={[st.label, { color: t.text }]}>{label}</Text>{children}</View>
  );
  const Chip = ({ on, label, onPress }: any) => (
    <Pressable onPress={onPress} style={[st.chip, { borderColor: t.accent, backgroundColor: on ? t.accent : 'transparent' }]}>
      <Text style={{ color: on ? '#fff' : t.text }}>{label}</Text>
    </Pressable>
  );
  const Btn = ({ label, onPress }: any) => (
    <Pressable onPress={onPress} style={[st.btn, { borderColor: t.accent }]}><Text style={{ color: t.accent }}>{label}</Text></Pressable>
  );
  const In = (p: any) => <TextInput {...p} placeholderTextColor={t.sub} autoCapitalize="none" autoCorrect={false}
    style={[st.input, { color: t.text, borderColor: t.sub }]} />;

  const toggleWake = async (v: boolean) => {
    if (!v) { WakeWordEngine.stop(); apply({ wakeEnabled: false }); return; }
    Alert.alert('Background listening',
      'JARVIS will keep the microphone on in a foreground service (a notification stays visible) so it can hear "Hello Jarvis". This uses battery. Audio is processed by Android\'s speech service; JARVIS does not record or store it.',
      [{ text: 'Cancel', style: 'cancel' }, { text: 'Enable', onPress: async () => {
        const ok = await WakeWordEngine.start();
        if (!ok) Alert.alert('Could not start', 'Microphone permission is needed, and this feature only works in the installed APK (not Expo Go).');
        apply({ wakeEnabled: ok }); setHealth(WakeWordEngine.health());
      } }]);
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <ScrollView style={{ flex: 1, backgroundColor: t.bg }} contentContainerStyle={{ padding: 20, paddingTop: 50 }}>
        <Text style={[st.h, { color: t.accent }]}>Settings</Text>

        <Text style={[st.sec, { color: t.sub }]}>VOICE</Text>
        <Row label="Language">
          <View style={st.chips}>{(['auto', 'en', 'hi'] as const).map(l => <Chip key={l} on={s.language === l} label={l === 'auto' ? 'Auto' : l === 'en' ? 'English' : 'हिन्दी'} onPress={() => apply({ language: l })} />)}</View>
        </Row>
        <Row label={`Speech speed ${s.speechRate.toFixed(1)}x`}>
          <View style={st.chips}>
            <Chip label="−" onPress={() => apply({ speechRate: Math.max(0.5, +(s.speechRate - 0.1).toFixed(1)) })} />
            <Chip label="+" onPress={() => apply({ speechRate: Math.min(2, +(s.speechRate + 0.1).toFixed(1)) })} />
          </View>
        </Row>
        <Row label={`Voice: ${voices.find(v => v.identifier === s.voice)?.name ?? 'System default'}`}>
          <Chip label="Next voice" onPress={() => {
            if (!voices.length) return;
            const i = voices.findIndex(v => v.identifier === s.voice);
            apply({ voice: voices[(i + 1) % voices.length].identifier });
          }} />
        </Row>
        <Row label="Continuous conversation"><Switch value={s.continuous} onValueChange={v => apply({ continuous: v })} /></Row>

        <Text style={[st.sec, { color: t.sub }]}>"HELLO JARVIS" BACKGROUND LISTENING</Text>
        <Row label="Listen in background"><Switch value={s.wakeEnabled} onValueChange={toggleWake} /></Row>
        <Text style={[st.note, { color: t.sub }]}>
          Status: {health.running ? 'service running' : 'service stopped'} · Draw-over-apps: {health.overlay ? 'granted' : 'NOT granted'} · Battery exemption: {health.batteryExempt ? 'granted' : 'NOT granted'}
        </Text>
        <Btn label="Allow draw over other apps (lets JARVIS open itself)" onPress={() => Native.requestOverlayPermission()} />
        <Btn label="Disable battery optimization for JARVIS" onPress={() => Native.requestIgnoreBatteryOptimizations()} />
        <Text style={[st.note, { color: t.sub }]}>
          Some phones (Xiaomi, Oppo, Vivo, Samsung, OnePlus, Huawei) also need "Autostart" and "Lock in recents" turned on for JARVIS, or they kill the service. Android 14+ will not let a microphone service restart itself after reboot; open the app once after a restart.
        </Text>

        <Text style={[st.sec, { color: t.sub }]}>PHONE LOCK</Text>
        <Row label={D.adminActive() ? 'Device admin: enabled' : 'Device admin: off'}>
          <Chip label="Enable" onPress={() => D.requestAdmin()} />
        </Row>
        <Text style={[st.note, { color: t.sub }]}>Only grants permission to lock the screen. JARVIS cannot unlock, read, or store your PIN, pattern or password.</Text>

        <Text style={[st.sec, { color: t.sub }]}>AI SERVICE</Text>
        <Row label="Provider">
          <View style={st.chips}>{(['openai', 'gemini'] as const).map(p => <Chip key={p} on={s.aiProvider === p} label={p === 'openai' ? 'OpenAI-compatible' : 'Gemini'} onPress={() => apply({ aiProvider: p })} />)}</View>
        </Row>
        {s.aiProvider === 'openai' && <In value={s.aiBaseUrl} onChangeText={(v: string) => apply({ aiBaseUrl: v })} placeholder="Base URL" />}
        <In value={s.aiModel} onChangeText={(v: string) => apply({ aiModel: v })} placeholder="Model" />
        <In value={s.aiApiKey} onChangeText={(v: string) => apply({ aiApiKey: v })} placeholder="API key (stored encrypted on this phone)" secureTextEntry />

        <Text style={[st.sec, { color: t.sub }]}>APPEARANCE & PRIVACY</Text>
        <Row label="Theme"><View style={st.chips}>
          <Chip on={s.theme === 'dark'} label="Dark" onPress={() => apply({ theme: 'dark' })} />
          <Chip on={s.theme === 'light'} label="Light" onPress={() => apply({ theme: 'light' })} />
        </View></Row>
        <Btn label="Delete conversation history" onPress={() => Alert.alert('Delete history?', '', [{ text: 'Cancel' }, { text: 'Delete', style: 'destructive', onPress: clear }])} />
        <Text style={[st.note, { color: t.sub }]}>The microphone is only used while the orb shows "Listening" or the background-listening notification is visible. Text you say is sent to your chosen AI provider.</Text>

        <Btn label="Close" onPress={onClose} />
        <Text style={[st.credit, { color: t.sub }]}>App by Ishant Upadhyay</Text>
      </ScrollView>
    </Modal>
  );
}

const st = StyleSheet.create({
  h: { fontSize: 28, fontWeight: '700', letterSpacing: 2, marginBottom: 10 },
  sec: { marginTop: 22, marginBottom: 6, fontSize: 12, letterSpacing: 1.5 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 8, flexWrap: 'wrap', gap: 8 },
  label: { fontSize: 16, flexShrink: 1 },
  chips: { flexDirection: 'row', gap: 6, flexWrap: 'wrap' },
  chip: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 12, paddingVertical: 6 },
  btn: { borderWidth: 1, borderRadius: 10, padding: 12, marginVertical: 6, alignItems: 'center' },
  input: { borderWidth: 1, borderRadius: 8, padding: 10, marginVertical: 5 },
  note: { fontSize: 12, lineHeight: 17, marginVertical: 4 },
  credit: { textAlign: 'center', marginTop: 24, fontSize: 12 },
});
