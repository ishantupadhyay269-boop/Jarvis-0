# JARVIS: Android AI voice assistant
App by Ishant Upadhyay

React Native + Expo (development build), TypeScript, plus a local native Kotlin module.
**Status: source code only. It has NOT been compiled or run on a phone yet.** Expect to fix a few
build or runtime errors on first build; follow the test checklist below before trusting any feature.

## Setup
1. Install Node 20+, JDK 17, Android Studio (SDK 35/36), and an EAS account (`npm i -g eas-cli`).
2. `npm install` then `npx expo install --fix` (aligns package versions to the Expo SDK).
3. Copy `.env.example` to `.env` (or enter the AI key later in Settings on the phone).
   - Free option: Groq key (OpenAI-compatible, default) or a Gemini key. Check each provider's current free-tier terms.
   - `EXPO_PUBLIC_*` values are bundled in the APK and can be extracted. For a private APK this is fine;
     for sharing, leave it blank and type the key in Settings (stored with expo-secure-store) or use your own proxy.
4. `npx tsc --noEmit` to typecheck.

## Build the APK (cloud, no Android Studio)
```
eas login
eas build:configure
eas build -p android --profile preview      # downloads a .apk link when finished
```
Local alternative: `npx expo prebuild --platform android` then `cd android && ./gradlew assembleRelease`
(release signing needs a keystore; EAS manages one for you).

## Install on phone
Open the EAS build link on the phone (or `adb install jarvis.apk`), allow "install unknown apps".

## First run: make "Hello Jarvis" work in the background
1. Settings → turn on **Listen in background** → allow microphone + notifications. A persistent notification appears.
2. Tap **Allow draw over other apps** (needed on Android 10+ so a background service can open the app).
3. Tap **Disable battery optimization**. On Xiaomi/Oppo/Vivo/Samsung/OnePlus/Huawei also enable Autostart and lock the app in Recents.
4. Lock the phone, say "Hello Jarvis". Expected: "Yes Sir." spoken, app opens, JARVIS listens for your command.

## How the background part works (and its limits)
- `WakeWordService.kt` is a foreground service (type microphone) looping Android's `SpeechRecognizer` and matching "jarvis".
  It is not a dedicated hotword DSP: battery use is noticeable, recognition may beep on some phones,
  and accuracy depends on Google's speech service. For better accuracy and battery, swap in Picovoice Porcupine
  (paid/limited free tier) behind `WakeWordEngine.ts`.
- Only one app can use the microphone at a time. JARVIS pauses the service while the app itself is listening.
- Android 14+ blocks starting a microphone service from boot; open the app once after a restart.
- Whether the screen-off wake works depends on the manufacturer. Some kill the service regardless.
- Not implemented: `VoiceInteractionService` (default-assistant registration / long-press power button).

## What the commands can and can't do
Works through official Android APIs: open apps, YouTube, camera, settings pages, dialer (opens dialer, you press call),
SMS composer (you press send), web search, flashlight, volume, alarm (opens the Clock app prefilled), battery, network, time/date,
lock screen (needs Device Admin), biometric authentication.
Cannot: unlock the lock screen, read your PIN, call/send SMS silently, or search contacts (no contacts permission requested).
"Unlock my phone" only runs BiometricPrompt and tells you Android must unlock itself.

## Test checklist (do these before trusting a feature)
- [ ] App builds and launches; orb animates.
- [ ] Mic button: speech recognised in English, then Hindi (Settings → Language).
- [ ] Typed question gets an AI answer and is spoken.
- [ ] "open camera", "open youtube", "flashlight on", "battery", "set alarm for 7 am".
- [ ] "authenticate me and open youtube" → fingerprint prompt → YouTube opens.
- [ ] "lock my phone" → device-admin prompt → screen locks.
- [ ] Background wake with app closed, then with screen off.

## Layout
`src/modules/`: VoiceEngine, WakeWordEngine, AIEngine, SpeechEngine, AndroidDeviceController, AuthenticationManager,
CommandProcessor, ConversationManager, SettingsManager. `src/ui/`: MainUI, Orb, SettingsScreen, useJarvis.
`modules/jarvis-native/`: Kotlin Expo module (wake service, device admin, flashlight, volume, app launcher).
