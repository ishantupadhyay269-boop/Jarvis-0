import React from 'react';
import { StatusBar } from 'expo-status-bar';
import MainUI from './src/ui/MainUI';

export default function App() {
  return (
    <>
      <StatusBar style="light" />
      <MainUI />
    </>
  );
}
